from __future__ import unicode_literals
from netmiko.ubiquiti.edge_ssh import UbiquitiEdgeSSH

__all__ = ['UbiquitiEdgeSSH']
